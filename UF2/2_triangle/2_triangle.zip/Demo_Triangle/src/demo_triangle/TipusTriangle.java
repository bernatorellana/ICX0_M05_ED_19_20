package demo_triangle;

/**
 *
 * @author Usuari
 */
public enum TipusTriangle {
    NO_TRIANGLE,
    EQUILATER,
    ISOSCELES,
    ESCALE
}
