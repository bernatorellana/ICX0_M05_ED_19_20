package net.iesmila.aillament;

import net.iesmila.aillament.EmailManager;
import net.iesmila.aillament.Persona;
import mockit.Expectations;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;
import mockit.NonStrictExpectations;
import mockit.Verifications;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author BERNAT
 */
public class PersonaTest {

    public PersonaTest() {
    }

    @Test
    public void testGetNom() {
    }

    @Test
    public void testGetCognom() {
    }

    @Test
    public void testGetNIF() {
    }

    @Test
    public void testEnviarEmail() {

        //-------------------------------------------------------
        Persona p = new Persona("Paco", "Pil", "1111111H", "pordios@nolohagas.com");

        boolean resultat = p.enviarEmail("Hola!", "Aix� �s un missatge");
        assertEquals(true, resultat);
        assertEquals(1, p.getEmailsEnviats());
        //--------------------------------------------------------------------
        resultat = p.enviarEmail("ERROR", "ARA VOLEM SIMULAR UN ERROR DE TRANSMISSI�");
        assertEquals(false, resultat);
        assertEquals(1, p.getEmailsEnviats());
        //--------------------------------------------------------------------
        Persona p2 = new Persona("Paco", "Pil", "1111111H", "EMAIL@NO_EXISTENT.COM");
        try {            
            resultat = p2.enviarEmail("Hola!", "Aix� �s un missatge");
            fail("els emails erronis han de petar");                        
        } catch (Exception ex) {
                // passar per aqu� �s el normal
        }
        assertEquals(0, p2.getEmailsEnviats());
        //--------------------------------------------------------------------


    }

}
