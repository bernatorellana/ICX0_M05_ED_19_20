public class HolaMon {
   public static void main(String args[]) {
      System.out.println("Hola m�n");
	  if( args.length>0) {
		System.out.println("Par�metre 1:" + args[0]);
	  }
   }
}