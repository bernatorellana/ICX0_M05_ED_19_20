package edu.iesmila.ed;

public class HolaMon {
    
    public static void main(String [] args) {
        System.out.println("Hola món");
    }
    
}